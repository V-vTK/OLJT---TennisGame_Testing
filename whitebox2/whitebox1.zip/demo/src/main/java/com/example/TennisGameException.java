package com.example;

public class TennisGameException extends Exception {

}
